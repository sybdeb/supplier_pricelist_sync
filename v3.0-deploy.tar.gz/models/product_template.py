# -*- coding: utf-8 -*-


# UNSPSC field removed - caused issues when module uninstalled
# If you need UNSPSC classification, install a dedicated UNSPSC module instead