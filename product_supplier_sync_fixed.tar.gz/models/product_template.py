# -*- coding: utf-8 -*-

from odoo import models, fields

# UNSPSC field removed - caused issues when module uninstalled
# If you need UNSPSC classification, install a dedicated UNSPSC module instead