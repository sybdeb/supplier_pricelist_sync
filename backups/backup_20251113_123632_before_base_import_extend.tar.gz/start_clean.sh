#!/bin/bash
cd /c/Users/Sybde/Projects/odoo-dev
./venv/Scripts/python ./odoo/odoo-bin -c odoo.conf -d odoo_dev_clean